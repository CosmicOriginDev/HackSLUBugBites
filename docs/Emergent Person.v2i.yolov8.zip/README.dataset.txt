# Emergent Person > 2024-04-17 11:01am
https://universe.roboflow.com/elizabeths-workspace/emergent-person

Provided by a Roboflow user
License: CC BY 4.0

